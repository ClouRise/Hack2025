<template>
    <div class="bg-zinc-100 h-full">
        <img class="cursor-pointer" @click="$emit('update:toggleUsers', false)" src="../assets/icons/close.svg" alt="">
    </div>
</template>

<script setup>
</script>