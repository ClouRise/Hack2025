<script setup>
import { RouterLink, RouterView } from 'vue-router'
</script>

<template>
  <div class="w-screen h-screen bg-amber-200">
  <RouterView />
  </div>
</template>

<style scoped>
*{
  padding: 0;
  margin: 0;
  box-sizing: border-box;
}
</style>
